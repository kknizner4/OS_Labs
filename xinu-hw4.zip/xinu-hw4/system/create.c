/**
 * @file create.c
 * 
 * @author Maximillian Marquez & Katie Knizner
 * TA-BOT:MAILTO maximillian.marquez@marquette.edu
 * COSC 3250 Assignment 4
 */
/* Embedded XINU, Copyright (C) 2008.  All rights reserved. */

#include <xinu.h>

static pid_typ newpid(void);
void userret(void);
void *getstk(ulong);

/**
 * Create a new process to start running a function.
 * @param funcaddr address of function that will begin in new process
 * @param ssize    stack size in bytes
 * @param name     name of the process, used for debugging
 * @param nargs    number of arguments that follow
 * @return the new process id
 */
syscall create(void *funcaddr, ulong ssize, char *name, ulong nargs, ...)
{
    ulong *saddr;               /* stack address                */
    ulong pid;                  /* stores new process id        */
    pcb *ppcb;                  /* pointer to proc control blk  */
    ulong i;
    va_list ap;                 /* points to list of var args   */
    ulong pads = 0;             /* padding entries in record.   */

    if (ssize < MINSTK)
        ssize = MINSTK;

    ssize = (ulong)((((ulong)(ssize + 3)) >> 2) << 2);
    /* round up to even boundary    */
    saddr = (ulong *)getstk(ssize);     /* allocate new stack and pid   */
    pid = newpid();
    /* a little error checking      */
    if ((((ulong *)SYSERR) == saddr) || (SYSERR == pid))
    {
        return SYSERR;
    }
    numproc++;
    ppcb = &proctab[pid];
    	
 	// TODO: Setup PCB entry for new process.
    	ppcb->state = PRSUSP;					//initial state is suspended
    	strncpy(ppcb->name, name, strlen(name) + 1); 		//name is input name 
    	ppcb->stkbase = saddr; 					// base of this stack is at the address we were just allocated by getstk() function
    	ppcb->stklen = ssize;					//stacklength is equal to size
    
    /* Initialize stack with accounting block. */
    *saddr = STACKMAGIC;
    *--saddr = pid;
    *--saddr = ppcb->stklen;
    *--saddr = (ulong)ppcb->stkbase;

    /* Handle variable number of arguments passed to starting function   */
    if (nargs)
    {
        pads = ((nargs - 1) / 8) * 8;
    }
    /* If more than 4 args, pad record size to multiple of native memory */
    /*  transfer size.  Reserve space for extra args                     */
    for (i = 0; i < pads; i++)
    {
        *--saddr = 0;
    }


	// TODO: Initialize process context.
	for(int i =0; i < CONTEXT; i++){ //set all registers to zero
		*--saddr = 0;
	}
	*(CTX_RA + saddr) = (ulong)userret;	//set return address
	*(CTX_SP + saddr) = (ulong) saddr;	//set stack pointer
	*(CTX_PC + saddr) = (ulong)funcaddr;	//set program counter
    	
	// TODO:  Place arguments into activation record.
	//        See K&R 7.3 for example using va_start, va_arg and
	//        va_end macros for variable argument functions.
	
	ulong ival;	//code from book. Go thru the argument pointer, for each new arg, put it into the process stack
	int w = 0;
	va_start(ap, nargs);
	ulong *p;
	for(p = ap; *p; p++){
		ival = va_arg(ap, ulong);
		*(w + saddr) = ival;
		w++;
		if(pads!=0 && w==8)	//after the eighth entry, we usually put in the registers in the stack, so we need to skip these 24 slots when putting in our arguments
		{
			w+=24;
		}
	}
	ppcb->stkptr = saddr;	//now that we're done adjusting the stack, wherever our saddr var ends up is the 'top' of the stack (stkptr)
	va_end(ap);		//close out the va function
    return pid;
}

/**
 * Obtain a new (free) process id.
 * @return a free process id, SYSERR if all ids are used
 */
static pid_typ newpid(void)
{
    pid_typ pid;                /* process id to return     */
    static pid_typ nextpid = 0;

    for (pid = 0; pid < NPROC; pid++)
    {                           /* check all NPROC slots    */
        nextpid = (nextpid + 1) % NPROC;
        if (PRFREE == proctab[nextpid].state)
        {
            return nextpid;
        }
    }
    return SYSERR;
}

/**
 * Entered when a process exits by return.
 */
void userret(void)
{
    // ASSIGNMENT 5 TODO: Replace the call to kill(); with user_kill();
    // when you believe your trap handler is working in Assignment 5
    // user_kill();
    kill(currpid); 
}
